import tkinter as tk
from app_nutri import AplikasiNutrisi

def main():
    root = tk.Tk()
    AplikasiNutrisi(root)
    root.mainloop()

if __name__ == "__main__":
    main()